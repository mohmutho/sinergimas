  </body>
</html>

<footer class="main-footer">
  <div class="pull-right hidden-xs"><b>Template Version</b> 2.0</div>
  <strong>Copyright &copy; 2016 <a href="http://azmicolejr.com">Azmi Cole Jr</a>.</strong> All rights reserved.
  Theme by <a href="http://almsaeedstudio.com">Almsaeed Studio</a>
</footer>